# Importation des modules nécessaires
import pdfplumber
import streamlit as st

# Extraction du texte des fichiers PDF
def extract_pdf_text(file) -> str:
    """
    Extrait le texte d'un fichier PDF.
    Retourne une chaîne vide si l'extraction échoue.
    """
    try:
        pdf_text = ""
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    pdf_text += text + "\n"
        if not pdf_text.strip():
            st.warning(f"Échec de l'extraction du texte pour {file.name}.")
            return ""
        return pdf_text
    except Exception as e:
        st.warning(f"Échec de l'extraction du texte pour {file.name}. Erreur : {str(e)}")
        return ""