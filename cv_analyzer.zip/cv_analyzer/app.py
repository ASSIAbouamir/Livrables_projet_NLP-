# Importation des modules nécessaires
import streamlit as st
from config import setup_logging, setup_page_config
from model import load_gemma_model
from pdf_processor import extract_pdf_text
from data_handler import process_cv_data, prepare_dataframe
from ui_components import render_candidate_form, render_results

# Configuration initiale
setup_logging()
setup_page_config()

# En-tête de l'application
st.title("Outil d'Analyse de CV")
st.markdown(
    "Téléchargez des CV au format PDF et entrez les informations des candidats pour extraire des données structurées."
)

# Chargement du modèle Gemma
with st.spinner("Chargement du modèle Gemma..."):
    lms = load_gemma_model()
    if not lms:
        st.error("Échec du chargement du modèle Gemma.")
        st.stop()

# Téléchargement des fichiers PDF
uploaded_files = st.file_uploader(
    "Téléchargez les CV au format PDF",
    type=["pdf"],
    accept_multiple_files=True,
    help="Sélectionnez un ou plusieurs fichiers PDF à analyser."
)

# Traitement des fichiers téléchargés
if uploaded_files:
    st.subheader("Informations des Candidats")
    candidate_data = render_candidate_form(uploaded_files)
    
    if st.button("Traiter les CV"):
        with st.spinner("Traitement des CV en cours..."):
            if any(not data["name"].strip() for data in candidate_data):
                st.error("Veuillez fournir des noms valides pour tous les candidats.")
            else:
                results = []
                for data in candidate_data:
                    pdf_text = extract_pdf_text(data["file"])
                    if pdf_text:
                        result = process_cv_data(data, pdf_text, lms)
                        if result:
                            results.append(result)
                
                if results:
                    df = prepare_dataframe(results)
                    render_results(df)
                else:
                    st.error("Aucune donnée valide extraite.")
else:
    st.info("Veuillez télécharger des fichiers PDF pour commencer.")