# Importation des modules nécessaires
import streamlit as st
import pandas as pd
import io
from datetime import date

# Affichage du formulaire des candidats
def render_candidate_form(uploaded_files) -> list:
    """
    Affiche les champs de saisie pour les informations des candidats.
    Retourne une liste de dictionnaires avec les données saisies.
    """
    candidate_data = []
    for file in uploaded_files:
        with st.expander(f"Informations pour {file.name}"):
            file_key = file.name.replace(".", "_").replace(" ", "_").replace("(", "").replace(")", "")
            name = st.text_input(
                "Nom complet",
                key=f"name_{file_key}",
                help="Entrez le nom complet du candidat."
            )
            gender = st.selectbox(
                "Genre",
                options=["Homme", "Femme", "Autre"],
                key=f"gender_{file_key}",
                help="Sélectionnez le genre du candidat."
            )
            dob = st.date_input(
                "Date de naissance",
                min_value=date(1900, 1, 1),
                max_value=date.today(),
                key=f"dob_{file_key}",
                help="Sélectionnez la date de naissance du candidat."
            )
            candidate_data.append({
                "file": file,
                "name": name,
                "gender": gender,
                "dob": dob,
                "filename": file.name
            })
    return candidate_data

# Affichage des résultats
def render_results(df: pd.DataFrame):
    """
    Affiche les résultats extraits et propose des options de téléchargement.
    """
    st.subheader("Informations des Candidats Extraites")
    st.dataframe(df, use_container_width=True)
    
    # Résultats quantitatifs
    st.subheader("Résultats Quantitatifs")
    avg_time = sum(float(row["Temps de traitement"].split()[0]) for row in df.to_dict("records")) / len(df) if len(df) > 0 else 0
    st.write(f"**Temps moyen de traitement par CV** : {avg_time:.4f} secondes")
    st.write(f"**Nombre total de CV traités** : {len(df)}")
    
    # Options de téléchargement
    col1, col2 = st.columns(2)
    
    with col1:
        csv = df.to_csv(index=False)
        st.download_button(
            label="Télécharger en CSV",
            data=csv,
            file_name="donnees_cv.csv",
            mime="text/csv"
        )
    
    with col2:
        output = io.BytesIO()
        try:
            # Essayer d'utiliser xlsxwriter en premier
            with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
                df.to_excel(writer, index=False)
        except ImportError:
            try:
                # Si xlsxwriter n'est pas disponible, utiliser openpyxl
                with pd.ExcelWriter(output, engine="openpyxl") as writer:
                    df.to_excel(writer, index=False)
            except ImportError:
                st.error("Veuillez installer 'xlsxwriter' ou 'openpyxl' pour exporter en Excel. Exécutez 'pip install xlsxwriter openpyxl'.")
                return
        st.download_button(
            label="Télécharger en Excel",
            data=output.getvalue(),
            file_name="donnees_cv.xlsx",
            mime="application/vnd.ms-excel"
        )