# Importation des modules nécessaires
import streamlit as st
import logging

# Configuration du journal de bord
def setup_logging():
    logging.basicConfig(level=logging.INFO)
    return logging.getLogger(__name__)

# Configuration de la mise en page Streamlit
def setup_page_config():
    st.set_page_config(layout="wide")