# Importation des modules nécessaires
import streamlit as st
import pandas as pd
import json
import time
import requests
import logging
import re

# Définition du prompt système
SYSTEM_PROMPT = """
Extrayez les informations structurées du texte du CV ci-dessous et renvoyez un seul objet JSON valide. 
Assurez-vous que l’objet JSON est propre et correctement formaté. 
N'essayez pas de deviner ou d'inventer des détails personnels.

Pour « Compétences », listez toutes les compétences mentionnées. 
Pour « autre », incluez toute information pertinente non couverte par les autres champs. 
Pour les langues, assurez-vous qu'il s'agit de langues naturelles (par exemple, arabe, anglais, français) et non de langages de programmation.

Format de sortie : json
{
  "compétences": [],
  "Diplôme": "",
  "autre": "",
  "Langues": []
}
"""

# Traitement des données du CV
def process_cv_data(data, pdf_text: str, lms) -> dict:
    """
    Traite le texte du CV pour extraire les informations structurées.
    Retourne un dictionnaire avec les résultats ou None en cas d'échec.
    """
    logger = logging.getLogger(__name__)
    start_time = time.time()
    
    try:
        # Préparation du prompt
        prompt = f"{SYSTEM_PROMPT}\n\n{pdf_text}"
        payload = {
            "model": "gemma-3-1b-it",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
            "max_tokens": -1,
            "stream": False
        }
        
        # Envoi de la requête au serveur LM Studio
        response = requests.post(
            "http://localhost:1234/v1/chat/completions",
            headers={"Content-Type": "application/json"},
            json=payload
        )
        response.raise_for_status()
        gemma_output = response.json()["choices"][0]["message"]["content"]
        
        # Nettoyage de la sortie
        gemma_output = gemma_output.strip()
        if gemma_output.startswith("```json") and gemma_output.endswith("```"):
            gemma_output = gemma_output[7:-3].strip()
        elif gemma_output.startswith("```") and gemma_output.endswith("```"):
            gemma_output = gemma_output[3:-3].strip()
        
        # Parsing de la sortie JSON
        try:
            parsed_output = json.loads(gemma_output)
            if not all(key in parsed_output for key in ["compétences", "Diplôme", "autre", "Langues"]):
                st.warning(f"Structure JSON invalide pour {data['filename']}.")
                return None
        except json.JSONDecodeError as e:
            st.warning(f"Échec du parsing JSON pour {data['filename']}. Erreur : {str(e)}")
            logger.error(f"Erreur de parsing JSON : {str(e)}, Sortie : {gemma_output}")
            return None
        
        processing_time = time.time() - start_time
        return {
            "Nom": data["name"],
            "Genre": data["gender"],
            "Date de naissance": data["dob"].strftime("%Y-%m-%d"),
            "Compétences": ", ".join(parsed_output["compétences"]),
            "Diplôme": parsed_output["Diplôme"],
            "Autre": parsed_output["autre"],
            "Langues": ", ".join(parsed_output["Langues"]),
            "Nom du fichier": data["filename"],
            "Temps de traitement": f"{processing_time:.4f} secondes"
        }
    
    except requests.exceptions.RequestException as e:
        st.error(f"Échec du traitement de {data['filename']}. Erreur serveur : {str(e)}")
        logger.error(f"Erreur serveur : {str(e)}")
        return None

# Préparation du DataFrame
def prepare_dataframe(results: list) -> pd.DataFrame:
    """
    Convertit les résultats en DataFrame pandas.
    """
    return pd.DataFrame(results)