# Importation des modules nécessaires
import streamlit as st
import logging

# Remarque : lmstudio nécessite un serveur LM Studio local en cours d'exécution sur http://localhost:1234

# Mise en cache du chargement du modèle
@st.cache_resource
def load_gemma_model() -> object:
    """
    Charge le modèle de langage via lmstudio.
    Retourne le modèle chargé ou None en cas d'échec.
    """
    logger = logging.getLogger(__name__)
    try:
        # Initialisation du modèle avec lmstudio
        import lmstudio as lms
        llm = lms.llm('gemma-3-1b-it')
        return llm
    except Exception as e:
        logger.error(f"Erreur lors du chargement du modèle lmstudio : {str(e)}")
        st.error(f"Échec du chargement du modèle lmstudio : {str(e)}")
        return None